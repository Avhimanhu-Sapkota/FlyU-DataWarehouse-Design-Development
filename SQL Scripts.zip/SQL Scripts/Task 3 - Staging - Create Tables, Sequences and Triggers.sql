--------------------------- STAGING AREA - TABLES -------------------------------
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
-- ALL SQL AND PL/SQL CODE REQUIRED FOR STAGING TABLE: DIM_DELAYED_FLIGHTS
---------------------------------------------------------------------------------

-- DROP TABLE STAGING_DELAYED_FLIGHTS BEFORE CREATION
DROP TABLE STAGING_DELAYED_FLIGHTS;

-- CREATE TABLE STAGING_DELAYED_FLIGHTS
CREATE TABLE STAGING_DELAYED_FLIGHTS(
    delayed_flight_id  INTEGER NOT NULL,
    flight_number  INTEGER,
    tail_number VARCHAR(50),
    air_system_delay    INTEGER,
    security_delay INTEGER,
    airline_delay   INTEGER,
    late_aircraft_delay INTEGER,
    weather_delay   INTEGER,
    flights_airline VARCHAR(20),
    Data_Source VARCHAR(20) NOT NULL,

    CONSTRAINT  pk_STAGING_DELAYED_FLIGHTS PRIMARY KEY (delayed_flight_id)
);

-- DROP SEQUENCE STAGING_DELAYED_FLIGHTS_SEQ BEFORE CREATION
DROP SEQUENCE STAGING_DELAYED_FLIGHTS_SEQ;

-- CREATE SEQUENCE STAGING_DELAYED_FLIGHTS_SEQ
CREATE SEQUENCE STAGING_DELAYED_FLIGHTS_SEQ INCREMENT BY 1 START WITH 1;

-- CREATE TRIGGER WHICH INCREASES THE VALUE OF PRIMARY KEY EVERY TIME A NEW DATA IS INSERTED.
CREATE OR REPLACE TRIGGER STAGING_DELAYED_FLIGHTS_TRIGGER
BEFORE INSERT ON STAGING_DELAYED_FLIGHTS 

FOR EACH ROW
BEGIN        
    :new.delayed_flight_id := STAGING_DELAYED_FLIGHTS_SEQ.NEXTVAL;
END;
/
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
-- ALL SQL AND PL/SQL CODE REQUIRED FOR STAGING TABLE: DIM_CANCELLED_FLIGHTS
---------------------------------------------------------------------------------

-- DROP TABLE STAGING_CANCELLED_FLIGHTS BEFORE CREATION
DROP TABLE STAGING_CANCELLED_FLIGHTS;

-- CREATE TABLE STAGING_CANCELLED_FLIGHTS
CREATE TABLE STAGING_CANCELLED_FLIGHTS(
    cancelled_flight_id INTEGER NOT NULL,
    flight_number   INTEGER,
    tail_number VARCHAR(50),
    flights_airline VARCHAR(20),
    cancellation_reason VARCHAR(8),
    Data_Source VARCHAR(20) NOT NULL,

    CONSTRAINT  pk_STAGING_CANCELLED_FLIGHTS PRIMARY KEY (cancelled_flight_id)
);

-- DROP SEQUENCE STAGING_CANCELLED_FLIGHTS_SEQ BEFORE CREATION
DROP SEQUENCE STAGING_CANCELLED_FLIGHTS_SEQ;

-- CREATE SEQUENCE STAGING_CANCELLED_FLIGHTS_SEQ
CREATE SEQUENCE STAGING_CANCELLED_FLIGHTS_SEQ INCREMENT BY 1 START WITH 1;

-- CREATE TRIGGER WHICH INCREASES THE VALUE OF PRIMARY KEY EVERY TIME A NEW DATA IS INSERTED.
CREATE OR REPLACE TRIGGER STAGING_CANCELLED_FLIGHTS_TRIGGER
BEFORE INSERT ON STAGING_CANCELLED_FLIGHTS 

FOR EACH ROW
BEGIN        
    :new.cancelled_flight_id := STAGING_CANCELLED_FLIGHTS_SEQ.NEXTVAL;
END;
/
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
-- ALL SQL AND PL/SQL CODE REQUIRED FOR STAGING TABLE: DIM_WEATHER_DATA
---------------------------------------------------------------------------------

-- DROP TABLE STAGING_WEATHER_DATA BEFORE CREATION
DROP TABLE STAGING_WEATHER_DATA;

-- CREATE TABLE STAGING_WEATHER_DATA
CREATE TABLE STAGING_WEATHER_DATA(
    weather_data_id INTEGER NOT NULL,
    weather_station VARCHAR(20),
    weather_date    VARCHAR(50),
    AWND    FLOAT(8),
    PRCP    FLOAT(8),
    TAVG    INTEGER,

    CONSTRAINT  pk_STAGING_WEATHER_DATA PRIMARY KEY (weather_data_id)
);

-- DROP SEQUENCE STAGING_WEATHER_DATA_SEQ BEFORE CREATION
DROP SEQUENCE STAGING_WEATHER_DATA_SEQ;

-- CREATE SEQUENCE STAGING_WEATHER_DATA_SEQ
CREATE SEQUENCE STAGING_WEATHER_DATA_SEQ INCREMENT BY 1 START WITH 1;

-- CREATE TRIGGER WHICH INCREASES THE VALUE OF PRIMARY KEY EVERY TIME A NEW DATA IS INSERTED.
CREATE OR REPLACE TRIGGER STAGING_WEATHER_DATA_TRIGGER
BEFORE INSERT ON STAGING_WEATHER_DATA

FOR EACH ROW
BEGIN        
    :new.weather_data_id := STAGING_WEATHER_DATA_SEQ.NEXTVAL;
END;
/
---------------------------------------------------------------------------------
-------------------------- END OF STAGING TABLE SCRIPT --------------------------
---------------------------------------------------------------------------------
