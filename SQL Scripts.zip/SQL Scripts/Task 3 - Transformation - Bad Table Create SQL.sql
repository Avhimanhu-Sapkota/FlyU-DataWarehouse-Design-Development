------------------------------- BAD DATA - TABLES -------------------------------
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
-- ALL SQL AND PL/SQL CODE REQUIRED FOR BAD DATA TABLE: DIM_DELAYED_FLIGHTS
---------------------------------------------------------------------------------

-- DROP TABLE BAD_DELAYED_FLIGHTS BEFORE CREATION
DROP TABLE BAD_DELAYED_FLIGHTS;

-- CREATE TABLE BAD_DELAYED_FLIGHTS
CREATE TABLE BAD_DELAYED_FLIGHTS(
    bad_delayed_flight_id  INTEGER NOT NULL,
    delayed_flight_id  INTEGER NOT NULL,
    flight_number  INTEGER,
    tail_number VARCHAR(50),
    air_system_delay    INTEGER,
    security_delay INTEGER,
    airline_delay   INTEGER,
    late_aircraft_delay INTEGER,
    weather_delay   INTEGER,
    flights_airline VARCHAR(20),
    Data_Source VARCHAR(20) NOT NULL,
    error_description VARCHAR(120),
    error_status VARCHAR(20),
    resolution_date DATE,

    CONSTRAINT  pk_BAD_DELAYED_FLIGHTS PRIMARY KEY (bad_delayed_flight_id)
);

-- DROP SEQUENCE BAD_DELAYED_FLIGHTS_SEQ BEFORE CREATION
DROP SEQUENCE BAD_DELAYED_FLIGHTS_SEQ;

-- CREATE SEQUENCE BAD_DELAYED_FLIGHTS_SEQ
CREATE SEQUENCE BAD_DELAYED_FLIGHTS_SEQ INCREMENT BY 1 START WITH 1;

-- CREATE TRIGGER WHICH INCREASES THE VALUE OF PRIMARY KEY EVERY TIME A NEW DATA IS INSERTED.
CREATE OR REPLACE TRIGGER BAD_DELAYED_FLIGHTS_TRIGGER
BEFORE INSERT ON BAD_DELAYED_FLIGHTS 

FOR EACH ROW
BEGIN        
    :new.bad_delayed_flight_id := BAD_DELAYED_FLIGHTS_SEQ.NEXTVAL;
END;
/
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
-- ALL SQL AND PL/SQL CODE REQUIRED FOR BAD TABLE: DIM_CANCELLED_FLIGHTS
---------------------------------------------------------------------------------

-- DROP TABLE BAD_CANCELLED_FLIGHTS BEFORE CREATION
DROP TABLE BAD_CANCELLED_FLIGHTS;

-- CREATE TABLE BAD_CANCELLED_FLIGHTS
CREATE TABLE BAD_CANCELLED_FLIGHTS(
    bad_cancelled_flight_id INTEGER NOT NULL,
    cancelled_flight_id INTEGER NOT NULL,
    flight_number   INTEGER,
    tail_number VARCHAR(50),
    flights_airline VARCHAR(20),
    cancellation_reason VARCHAR(8),
    Data_Source VARCHAR(20) NOT NULL,
    error_description VARCHAR(120),
    error_status VARCHAR(20),
    resolution_date DATE,

    CONSTRAINT  pk_BAD_CANCELLED_FLIGHTS PRIMARY KEY (bad_cancelled_flight_id)
);

-- DROP SEQUENCE BAD_CANCELLED_FLIGHTS_SEQ BEFORE CREATION
DROP SEQUENCE BAD_CANCELLED_FLIGHTS_SEQ;

-- CREATE SEQUENCE BAD_CANCELLED_FLIGHTS_SEQ
CREATE SEQUENCE BAD_CANCELLED_FLIGHTS_SEQ INCREMENT BY 1 START WITH 1;

-- CREATE TRIGGER WHICH INCREASES THE VALUE OF PRIMARY KEY EVERY TIME A NEW DATA IS INSERTED.
CREATE OR REPLACE TRIGGER BAD_CANCELLED_FLIGHTS_TRIGGER
BEFORE INSERT ON BAD_CANCELLED_FLIGHTS 

FOR EACH ROW
BEGIN        
    :new.bad_cancelled_flight_id := BAD_CANCELLED_FLIGHTS_SEQ.NEXTVAL;
END;
/
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
-- ALL SQL AND PL/SQL CODE REQUIRED FOR BAD TABLE: DIM_WEATHER_DATA
---------------------------------------------------------------------------------

-- DROP TABLE BAD_WEATHER_DATA BEFORE CREATION
DROP TABLE BAD_WEATHER_DATA;

-- CREATE TABLE BAD_WEATHER_DATA
CREATE TABLE BAD_WEATHER_DATA(
    bad_weather_data_id INTEGER NOT NULL,
    weather_data_id INTEGER NOT NULL,
    weather_station VARCHAR(20),
    weather_date    VARCHAR(50),
    AWND    FLOAT(8),
    PRCP    FLOAT(8),
    TAVG    INTEGER,
    error_description VARCHAR(120),
    error_status VARCHAR(20),
    resolution_date DATE,

    CONSTRAINT  pk_BAD_WEATHER_DATA PRIMARY KEY (bad_weather_data_id)
);

-- DROP SEQUENCE BAD_WEATHER_DATA_SEQ BEFORE CREATION
DROP SEQUENCE BAD_WEATHER_DATA_SEQ;

-- CREATE SEQUENCE BAD_WEATHER_DATA_SEQ
CREATE SEQUENCE BAD_WEATHER_DATA_SEQ INCREMENT BY 1 START WITH 1;

-- CREATE TRIGGER WHICH INCREASES THE VALUE OF PRIMARY KEY EVERY TIME A NEW DATA IS INSERTED.
CREATE OR REPLACE TRIGGER BAD_WEATHER_DATA_TRIGGER
BEFORE INSERT ON BAD_WEATHER_DATA

FOR EACH ROW
BEGIN        
    :new.bad_weather_data_id := BAD_WEATHER_DATA_SEQ.NEXTVAL;
END;
/
---------------------------------------------------------------------------------
---------------------------- END OF BAD DATA CREATION ---------------------------
---------------------------------------------------------------------------------
