--------------------------- TRANSFORMATION DATA TABLES --------------------------
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
-- ALL SQL AND PL/SQL CODE REQUIRED FOR TRANSFORMATION TABLE: DIM_DELAYED_FLIGHTS
---------------------------------------------------------------------------------

-- DROP TABLE TRANSFORM_DELAYED_FLIGHTS BEFORE CREATION
DROP TABLE TRANSFORM_DELAYED_FLIGHTS;

-- CREATE TABLE TRANSFORM_DELAYED_FLIGHTS
CREATE TABLE TRANSFORM_DELAYED_FLIGHTS(
    delayed_flight_id   INTEGER NOT NULL,
    flight_number   INTEGER NOT NULL,
    tail_number VARCHAR(50) NOT NULL,
    air_system_delay    INTEGER NOT NULL,
    security_delay  INTEGER NOT NULL,
    airline_delay   INTEGER NOT NULL,
    late_aircraft_delay INTEGER NOT NULL,
    weather_delay   INTEGER NOT NULL,
    flights_airline VARCHAR(20) NOT NULL,
    Data_Source VARCHAR(20) NOT NULL,

    CONSTRAINT  pk_TRANSFORM_DELAYED_FLIGHTS PRIMARY KEY (delayed_flight_id)
);
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
--ALL SQL AND PL/SQL CODE REQUIRED FOR TRANSFORMATION TABLE: DIM_CANCELLED_FLIGHTS
---------------------------------------------------------------------------------

-- DROP TABLE TRANSFORM_CANCELLED_FLIGHTS BEFORE CREATION
DROP TABLE TRANSFORM_CANCELLED_FLIGHTS;

-- CREATE TABLE TRANSFORM_CANCELLED_FLIGHTS
CREATE TABLE TRANSFORM_CANCELLED_FLIGHTS(
    cancelled_flight_id INTEGER NOT NULL,
    flight_number   INTEGER NOT NULL,
    tail_number VARCHAR(50) NOT NULL,
    flights_airline VARCHAR(20) NOT NULL,
    cancellation_reason VARCHAR(120) NOT NULL,
    Data_Source VARCHAR(20) NOT NULL,

    CONSTRAINT  pk_TRANSFORM_CANCELLED_FLIGHTS PRIMARY KEY (cancelled_flight_id)
);
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
-- ALL SQL AND PL/SQL CODE REQUIRED FOR TRANSFORMATION TABLE: DIM_WEATHER_DATA
---------------------------------------------------------------------------------

-- DROP TABLE TRANSFORM_WEATHER_DATA BEFORE CREATION
DROP TABLE TRANSFORM_WEATHER_DATA;

-- CREATE TABLE TRANSFORM_WEATHER_DATA
CREATE TABLE TRANSFORM_WEATHER_DATA(
    weather_data_id INTEGER NOT NULL,
    weather_station VARCHAR(20) NOT NULL,
    weather_date    DATE NOT NULL,
    AWND    FLOAT(8) NOT NULL,
    PRCP    FLOAT(8) NOT NULL,
    TAVG    INTEGER NOT NULL,

    CONSTRAINT  pk_TRANSFORM_WEATHER_DATA PRIMARY KEY (weather_data_id)
);
------------------------------------------------------------------------------------------------------- END OF TRANSFORMATION TABLE CREATION CODE ----------------
---------------------------------------------------------------------------------
